﻿namespace NROREG.Model;
public class Class1
{

}
