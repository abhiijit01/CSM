namespace NROREG.Model.BaseEntityModel
{
	public class BaseEntity
	{
		public int ContinentId { get; set; } = 0;
		public int CountryId { get; set; } = 0;
		public int intDistrictId { get; set; } = 0;
		public int intId { get; set; } = 0;
		public string name { get; set; } = "";
		public int population { get; set; } = 0;
		public string vchName { get; set; } = "";
	}
}

