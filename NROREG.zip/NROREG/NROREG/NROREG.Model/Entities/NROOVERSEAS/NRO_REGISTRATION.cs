using System;
using NROREG.Model.BaseEntityModel;
namespace NROREG.Model.NRO_REGISTRATION
{
	public class NRO_REGISTRATION : BaseEntity
	{
		public int REGID { get; set; }
		public string? FullName { get; set; }
		public string? LatestPhotograph { get; set; }
		public string? DateOfBirth { get; set; }
		public string? Gender { get; set; }
		public string? BloodGroup { get; set; }
		public int? AGE { get; set; }
		public string? Occupation { get; set; }
		public string? AadharCardNumber { get; set; }
		public string? MobileNumber { get; set; }
		public string? AlternativePhoneNumber { get; set; }
		public string? WhatsAppNumber { get; set; }
		public string? EmailAddress { get; set; }
		public string? FatherName { get; set; }
		public string? MotherName { get; set; }
		public string? MaritalStatus { get; set; }
		public string? SpouseName { get; set; }
		public bool? HaveChildren { get; set; }
		public int? NumberOfChildren { get; set; }
		public string? ChildName { get; set; }
		public int? ChildAge { get; set; }
		public string? PostalAddress { get; set; }
		public string? NearestLandmark { get; set; }
		public int? CountryID { get; set; }
		public int? StateID { get; set; }
		public int? CityID { get; set; }
		public string? ZipCode { get; set; }
		public int? Continent { get; set; }
		public bool? RuralUrbanCheckbox { get; set; }
		public string? AddressLine1 { get; set; }
		public string? AddressLine2 { get; set; }
		public int? NatStateID { get; set; }
		public int? DistrictID { get; set; }
		public int? UrbanULB { get; set; }
		public string? UrbanWardNumber { get; set; }
		public int? RuralBlock { get; set; }
		public int? RuralGramPanchayat { get; set; }
		public string? RuralVillage { get; set; }
		public int? PoliceStation { get; set; }
		public bool? AltRuralUrbanCheckbox { get; set; }
		public string? AltAddressLine1 { get; set; }
		public string? AltAddressLine2 { get; set; }
		public int? AltStateID { get; set; }
		public int? AltDistrictID { get; set; }
		public int? AltUrbanULB { get; set; }
		public string? AltUrbanWardNumber { get; set; }
		public int? AltRuralBlock { get; set; }
		public int? AltRuralGramPanchayat { get; set; }
		public string? AltRuralVillage { get; set; }
		public int? AltPoliceStation { get; set; }
		public int? HighestDegree { get; set; }
		public string? AreaOfInterest { get; set; }
		public string? PassportNumber { get; set; }
		public string? PlaceOfIssue { get; set; }
		public string? DateOfIssue { get; set; }
		public string? ExpiryDate { get; set; }
		public string? PassportDocument { get; set; }
		public string? VISA_Number { get; set; }
		public string? DateOfDeparture { get; set; }
		public string? VISA_ExpiryDate { get; set; }
		public string? VisaDocument { get; set; }
		public string? CompanyName { get; set; }
		public string? CompanyWebsite { get; set; }
		public string? CompanyEmail { get; set; }
		public string? CompanyAddress { get; set; }
		public string? ContactPersonName { get; set; }
		public string? ContactPersonDesignation { get; set; }
		public string? ContactPersonMobileNumber { get; set; }
	}
}

