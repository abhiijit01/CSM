using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NROREG.Model.NRO_REGISTRATION;
using NROREG.Repository.Repositories.Interfaces;
namespace NROREG.Web
{
 public class NROOVERSEASController : Controller
 {
 	 
		public IConfiguration Configuration;
		private readonly INROOVERSEASRepository _NROOVERSEASRepository;
        private IWebHostEnvironment _hostingEnvironment;
		public NROOVERSEASController(IConfiguration configuration,INROOVERSEASRepository NROOVERSEASRepository,IWebHostEnvironment hostingEnvironment)
		{
		Configuration = configuration;
	_NROOVERSEASRepository = NROOVERSEASRepository;
		
            _hostingEnvironment = hostingEnvironment;}
		[HttpGet]
		public IActionResult NROREGISTRATION()
		{
		return View();
		}
		[HttpPost]
		public IActionResult NROREGISTRATION(NRO_REGISTRATION TBL)
		{
		if (!ModelState.IsValid)
		{
			var message = string.Join(" | ", ModelState.Values
			 .SelectMany(v => v.Errors)
			.Select(e => e.ErrorMessage));
			return Json(new { sucess = false, responseMessage = message, responseText = "Model State is invalid", data = "" });
		}
		else
		{
				if (TBL.REGID == 0 || TBL.REGID == null)
				{
                    var data = _NROOVERSEASRepository.Insert_NRO_REGISTRATION(TBL);
                    return Json(new { sucess = true, responseMessage = "Inserted Successfully.", responseText = "Success", data = data });
                }
				else
				{
                    var data = _NROOVERSEASRepository.Insert_NRO_REGISTRATION(TBL);
                    return Json(new { sucess = true, responseMessage = "Updated Successfully.", responseText = "Success", data = data });
                }
            
		}}
	
		[HttpGet]
		public IActionResult ViewNROREGISTRATION()
		{
		return View();
		}
		[HttpGet]
		public async Task<JsonResult> Get_NROREGISTRATION()
		{
		if (!ModelState.IsValid)
		{
			var message = string.Join(" | ", ModelState.Values
 .SelectMany(v => v.Errors)
.Select(e => e.ErrorMessage));
			return Json(new { sucess = false, responseMessage = message, responseText = "Model State is invalid", data = "" });
		}
		else
		{
			List<NRO_REGISTRATION>			 lst =await 			 _NROOVERSEASRepository.Getall_NRO_REGISTRATION(new NRO_REGISTRATION());
		var jsonres = JsonConvert.SerializeObject(lst);
		
		return Json(jsonres);
		
}
		
}[HttpPost]
        public async Task<IActionResult> Search_NRO_REGISTRATION([FromBody]NRO_REGISTRATION BL)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
     .SelectMany(v => v.Errors)
    .Select(e => e.ErrorMessage));
                return Json(new { sucess = false, responseMessage = message, responseText = "Model State is invalid", data = "" });
            }
            else
            {
                List<NRO_REGISTRATION> lst = await _NROOVERSEASRepository.Search_NRO_REGISTRATION(BL);
                var jsonres = JsonConvert.SerializeObject(lst);

                return Json(jsonres);

            }

        }

        [HttpDelete]
       
        public async Task<JsonResult> Delete_NROREGISTRATION(int Id)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage));
                return Json(new { sucess = false, responseMessage = message, responseText = "Model State is invalid", data = "" });
            }
            else
            {
                var data =_NROOVERSEASRepository.Delete_NRO_REGISTRATION(Id);
                return Json(new { sucess = true, responseMessage = "Action taken Successfully.", responseText = "Success", data = data });
            }
        }

		[HttpGet]
       
        public async Task<JsonResult> GetByID_NROREGISTRATION(int Id)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e => e.ErrorMessage));
                return Json(new { sucess = false, responseMessage = message, responseText = "Model State is invalid", data = "" });
            }
            else
            {
NRO_REGISTRATION lst = await _NROOVERSEASRepository.GetNRO_REGISTRATIONById(Id);
              var jsonres = JsonConvert.SerializeObject(lst);
            return Json(jsonres);
         }
        }

}
}
