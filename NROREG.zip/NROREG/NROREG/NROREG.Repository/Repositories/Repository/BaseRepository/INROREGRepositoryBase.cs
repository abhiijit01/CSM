using System;
using System.Collections.Generic;
using System.Data;

namespace NROREG.Repository.BaseRepository
{
    public interface INROREGRepositoryBase :IDisposable
    {
   

    }
  
}
