using System.Collections.Generic;
using NROREG.Repository.Factory;
using NROREG.Repository.BaseRepository;
using NROREG.Repository.Repositories.Interfaces;
using NROREG.Repository;

using NROREG.Model.NRO_REGISTRATION;
using Dapper;
using System.Data;
namespace NROREG.Repository.Repository
{
	public class NROOVERSEASRepository:NROREGRepositoryBase,INROOVERSEASRepository
	{
		public NROOVERSEASRepository(INROREGConnectionFactory NROREGConnectionFactory) : base(NROREGConnectionFactory)
        {

        }
		 public async Task<int> Insert_NRO_REGISTRATION(NRO_REGISTRATION TBL)
	{
		var p = new DynamicParameters();
		if(TBL.REGID == 0 )
		{
			p.Add("@P_Action", "I");
			p.Add("@P_REGID",0);
		}
		else
		{
			p.Add("@P_Action", "U");
			p.Add("@P_REGID",TBL.REGID);
		}
		p.Add("@P_FullName",TBL.FullName);
		p.Add("@P_LatestPhotograph",TBL.LatestPhotograph);
		p.Add("@P_DateOfBirth",TBL.DateOfBirth);
		p.Add("@P_Gender",TBL.Gender);
		p.Add("@P_BloodGroup",TBL.BloodGroup);
		p.Add("@P_AGE",TBL.AGE);
		p.Add("@P_Occupation",TBL.Occupation);
		p.Add("@P_AadharCardNumber",TBL.AadharCardNumber);
		p.Add("@P_MobileNumber",TBL.MobileNumber);
		p.Add("@P_AlternativePhoneNumber",TBL.AlternativePhoneNumber);
		p.Add("@P_WhatsAppNumber",TBL.WhatsAppNumber);
		p.Add("@P_EmailAddress",TBL.EmailAddress);
		p.Add("@P_FatherName",TBL.FatherName);
		p.Add("@P_MotherName",TBL.MotherName);
		p.Add("@P_MaritalStatus",TBL.MaritalStatus);
		p.Add("@P_SpouseName",TBL.SpouseName);
		p.Add("@P_HaveChildren",TBL.HaveChildren);
		p.Add("@P_NumberOfChildren",TBL.NumberOfChildren);
		p.Add("@P_ChildName",TBL.ChildName);
		p.Add("@P_ChildAge",TBL.ChildAge);
		p.Add("@P_PostalAddress",TBL.PostalAddress);
		p.Add("@P_NearestLandmark",TBL.NearestLandmark);
		p.Add("@P_CountryID",TBL.CountryID);
		p.Add("@P_StateID",TBL.StateID);
		p.Add("@P_CityID",TBL.CityID);
		p.Add("@P_ZipCode",TBL.ZipCode);
		p.Add("@P_Continent",TBL.Continent);
		p.Add("@P_RuralUrbanCheckbox",TBL.RuralUrbanCheckbox);
		p.Add("@P_AddressLine1",TBL.AddressLine1);
		p.Add("@P_AddressLine2",TBL.AddressLine2);
		p.Add("@P_NatStateID",TBL.NatStateID);
		p.Add("@P_DistrictID",TBL.DistrictID);
		p.Add("@P_UrbanULB",TBL.UrbanULB);
		p.Add("@P_UrbanWardNumber",TBL.UrbanWardNumber);
		p.Add("@P_RuralBlock",TBL.RuralBlock);
		p.Add("@P_RuralGramPanchayat",TBL.RuralGramPanchayat);
		p.Add("@P_RuralVillage",TBL.RuralVillage);
		p.Add("@P_PoliceStation",TBL.PoliceStation);
		p.Add("@P_AltRuralUrbanCheckbox",TBL.AltRuralUrbanCheckbox);
		p.Add("@P_AltAddressLine1",TBL.AltAddressLine1);
		p.Add("@P_AltAddressLine2",TBL.AltAddressLine2);
		p.Add("@P_AltStateID",TBL.AltStateID);
		p.Add("@P_AltDistrictID",TBL.AltDistrictID);
		p.Add("@P_AltUrbanULB",TBL.AltUrbanULB);
		p.Add("@P_AltUrbanWardNumber",TBL.AltUrbanWardNumber);
		p.Add("@P_AltRuralBlock",TBL.AltRuralBlock);
		p.Add("@P_AltRuralGramPanchayat",TBL.AltRuralGramPanchayat);
		p.Add("@P_AltRuralVillage",TBL.AltRuralVillage);
		p.Add("@P_AltPoliceStation",TBL.AltPoliceStation);
		p.Add("@P_HighestDegree",TBL.HighestDegree);
		p.Add("@P_AreaOfInterest",TBL.AreaOfInterest);
		p.Add("@P_PassportNumber",TBL.PassportNumber);
		p.Add("@P_PlaceOfIssue",TBL.PlaceOfIssue);
		p.Add("@P_DateOfIssue",TBL.DateOfIssue);
		p.Add("@P_ExpiryDate",TBL.ExpiryDate);
		p.Add("@P_PassportDocument",TBL.PassportDocument);
		p.Add("@P_VISA_Number",TBL.VISA_Number);
		p.Add("@P_DateOfDeparture",TBL.DateOfDeparture);
		p.Add("@P_VISA_ExpiryDate",TBL.VISA_ExpiryDate);
		p.Add("@P_VisaDocument",TBL.VisaDocument);
		p.Add("@P_CompanyName",TBL.CompanyName);
		p.Add("@P_CompanyWebsite",TBL.CompanyWebsite);
		p.Add("@P_CompanyEmail",TBL.CompanyEmail);
		p.Add("@P_CompanyAddress",TBL.CompanyAddress);
		p.Add("@P_ContactPersonName",TBL.ContactPersonName);
		p.Add("@P_ContactPersonDesignation",TBL.ContactPersonDesignation);
		p.Add("@P_ContactPersonMobileNumber",TBL.ContactPersonMobileNumber);
		var results = await Connection.ExecuteAsync("USP_NRO_REGISTRATION", p, commandType: CommandType.StoredProcedure);		
return 1;

		} 
	public async Task<int> Delete_NRO_REGISTRATION(int Id)
	{
				var p = new DynamicParameters();
		p.Add("@P_Action", "D");
			p.Add("@P_REGID",Id);
		
		var results = await Connection.ExecuteAsync("USP_NRO_REGISTRATION", p, commandType: CommandType.StoredProcedure);
		return results;

		} 
	public async Task<NRO_REGISTRATION> GetNRO_REGISTRATIONById(int Id)
	{
				var p = new DynamicParameters();
		p.Add("@P_Action", "E");
			p.Add("@P_REGID",Id);
		
		var results = await Connection.QueryAsync<NRO_REGISTRATION>("USP_NRO_REGISTRATION", p, commandType: CommandType.StoredProcedure);
		return results.FirstOrDefault();

		} 
	public async Task<List<NRO_REGISTRATION>> Getall_NRO_REGISTRATION(NRO_REGISTRATION TBL)
	{
				var p = new DynamicParameters();
		p.Add("@P_Action", "V");
		var results = await Connection.QueryAsync<NRO_REGISTRATION>("USP_NRO_REGISTRATION",p, commandType: CommandType.StoredProcedure);
		return results.ToList();

		} 
	public async Task<List<NRO_REGISTRATION>> Search_NRO_REGISTRATION(NRO_REGISTRATION TBL)
	{
				var p = new DynamicParameters();
		p.Add("@P_Action", "S");
			p.Add("@P_REGID",TBL.REGID);
		
		p.Add("@P_FullName",TBL.FullName);
		p.Add("@P_LatestPhotograph",TBL.LatestPhotograph);
		p.Add("@P_DateOfBirth",TBL.DateOfBirth);
		p.Add("@P_Gender",TBL.Gender);
		p.Add("@P_BloodGroup",TBL.BloodGroup);
		p.Add("@P_AGE",TBL.AGE);
		p.Add("@P_Occupation",TBL.Occupation);
		p.Add("@P_AadharCardNumber",TBL.AadharCardNumber);
		p.Add("@P_MobileNumber",TBL.MobileNumber);
		p.Add("@P_AlternativePhoneNumber",TBL.AlternativePhoneNumber);
		p.Add("@P_WhatsAppNumber",TBL.WhatsAppNumber);
		p.Add("@P_EmailAddress",TBL.EmailAddress);
		p.Add("@P_FatherName",TBL.FatherName);
		p.Add("@P_MotherName",TBL.MotherName);
		p.Add("@P_MaritalStatus",TBL.MaritalStatus);
		p.Add("@P_SpouseName",TBL.SpouseName);
		p.Add("@P_HaveChildren",TBL.HaveChildren);
		p.Add("@P_NumberOfChildren",TBL.NumberOfChildren);
		p.Add("@P_ChildName",TBL.ChildName);
		p.Add("@P_ChildAge",TBL.ChildAge);
		p.Add("@P_PostalAddress",TBL.PostalAddress);
		p.Add("@P_NearestLandmark",TBL.NearestLandmark);
		p.Add("@P_CountryID",TBL.CountryID);
		p.Add("@P_StateID",TBL.StateID);
		p.Add("@P_CityID",TBL.CityID);
		p.Add("@P_ZipCode",TBL.ZipCode);
		p.Add("@P_Continent",TBL.Continent);
		p.Add("@P_RuralUrbanCheckbox",TBL.RuralUrbanCheckbox);
		p.Add("@P_AddressLine1",TBL.AddressLine1);
		p.Add("@P_AddressLine2",TBL.AddressLine2);
		p.Add("@P_NatStateID",TBL.NatStateID);
		p.Add("@P_DistrictID",TBL.DistrictID);
		p.Add("@P_UrbanULB",TBL.UrbanULB);
		p.Add("@P_UrbanWardNumber",TBL.UrbanWardNumber);
		p.Add("@P_RuralBlock",TBL.RuralBlock);
		p.Add("@P_RuralGramPanchayat",TBL.RuralGramPanchayat);
		p.Add("@P_RuralVillage",TBL.RuralVillage);
		p.Add("@P_PoliceStation",TBL.PoliceStation);
		p.Add("@P_AltRuralUrbanCheckbox",TBL.AltRuralUrbanCheckbox);
		p.Add("@P_AltAddressLine1",TBL.AltAddressLine1);
		p.Add("@P_AltAddressLine2",TBL.AltAddressLine2);
		p.Add("@P_AltStateID",TBL.AltStateID);
		p.Add("@P_AltDistrictID",TBL.AltDistrictID);
		p.Add("@P_AltUrbanULB",TBL.AltUrbanULB);
		p.Add("@P_AltUrbanWardNumber",TBL.AltUrbanWardNumber);
		p.Add("@P_AltRuralBlock",TBL.AltRuralBlock);
		p.Add("@P_AltRuralGramPanchayat",TBL.AltRuralGramPanchayat);
		p.Add("@P_AltRuralVillage",TBL.AltRuralVillage);
		p.Add("@P_AltPoliceStation",TBL.AltPoliceStation);
		p.Add("@P_HighestDegree",TBL.HighestDegree);
		p.Add("@P_AreaOfInterest",TBL.AreaOfInterest);
		p.Add("@P_PassportNumber",TBL.PassportNumber);
		p.Add("@P_PlaceOfIssue",TBL.PlaceOfIssue);
		p.Add("@P_DateOfIssue",TBL.DateOfIssue);
		p.Add("@P_ExpiryDate",TBL.ExpiryDate);
		p.Add("@P_PassportDocument",TBL.PassportDocument);
		p.Add("@P_VISA_Number",TBL.VISA_Number);
		p.Add("@P_DateOfDeparture",TBL.DateOfDeparture);
		p.Add("@P_VISA_ExpiryDate",TBL.VISA_ExpiryDate);
		p.Add("@P_VisaDocument",TBL.VisaDocument);
		p.Add("@P_CompanyName",TBL.CompanyName);
		p.Add("@P_CompanyWebsite",TBL.CompanyWebsite);
		p.Add("@P_CompanyEmail",TBL.CompanyEmail);
		p.Add("@P_CompanyAddress",TBL.CompanyAddress);
		p.Add("@P_ContactPersonName",TBL.ContactPersonName);
		p.Add("@P_ContactPersonDesignation",TBL.ContactPersonDesignation);
		p.Add("@P_ContactPersonMobileNumber",TBL.ContactPersonMobileNumber);
		var results = await Connection.QueryAsync<NRO_REGISTRATION>("USP_NRO_REGISTRATION",p, commandType: CommandType.StoredProcedure);
		return results.ToList();

		} 
	
}
}
