using System.Collections.Generic;

using NROREG.Model.NRO_REGISTRATION;
namespace NROREG.Repository.Repositories.Interfaces
{
  public interface INROOVERSEASRepository
  {
  	 
        Task<int> Insert_NRO_REGISTRATION(NRO_REGISTRATION TBL);
        Task<int> Delete_NRO_REGISTRATION(int Id);
        Task<NRO_REGISTRATION> GetNRO_REGISTRATIONById(int Id);
        Task<List<NRO_REGISTRATION>> Search_NRO_REGISTRATION(NRO_REGISTRATION TBL);
        Task<List<NRO_REGISTRATION>> Getall_NRO_REGISTRATION(NRO_REGISTRATION TBL);
}
}
