using System.Data;

namespace NROREG.Repository.Factory
{
     public interface INROREGConnectionFactory
    {
        /// <summary>
        /// Gets the get connection.
        /// </summary>
        /// <value>The get connection.</value>
        IDbConnection GetConnection { get; }
    }
}
