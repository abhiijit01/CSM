using  Microsoft.Extensions.DependencyInjection;
using  Microsoft.Extensions.Configuration;

using NROREG.Repository.Factory;
using NROREG.Repository.Repository;
using NROREG.Repository.Repositories.Interfaces;
namespace NROREG.Repository.Container
{
	public static class CustomContainer
	{
		public static void AddCustomContainer(this IServiceCollection services, IConfiguration configuration)
		{
		INROREGConnectionFactory NROREGconnectionFactory=new NROREGConnectionFactory(configuration.GetConnectionString("DBconnectionNROREG"));
		services.AddSingleton<INROREGConnectionFactory> (NROREGconnectionFactory);

		services.AddScoped<INROOVERSEASRepository, NROOVERSEASRepository>();
			//Write code here
		}
	}
}
