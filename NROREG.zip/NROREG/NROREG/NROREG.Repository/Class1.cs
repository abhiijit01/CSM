﻿namespace NROREG.Repository;
public class Class1
{

}
