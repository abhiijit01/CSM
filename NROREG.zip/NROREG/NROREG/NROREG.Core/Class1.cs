﻿namespace NROREG.Core;
public class Class1
{

}
